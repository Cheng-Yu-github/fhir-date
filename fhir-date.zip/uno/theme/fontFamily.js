export default {
  sans: [
    {
      name: 'Open Sans',
      weights: ['300', '400', '500', '600', '700', '800'],
      italic: true,
    },
  ],
  mono: [
    {
      name: 'Fira Code',
      weights: ['400', '500', '600', '700'],
    },
  ],
}
